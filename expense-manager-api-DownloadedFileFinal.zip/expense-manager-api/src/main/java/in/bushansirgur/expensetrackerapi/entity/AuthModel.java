package in.bushansirgur.expensetrackerapi.entity;

import lombok.Data;

@Data
public class AuthModel {

	private String email;
	
	private String password;
}
